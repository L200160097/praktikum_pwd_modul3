<?php
echo 'halo dunia! </br>';
echo 'ini <i>script</i> php pertamaku';
?>