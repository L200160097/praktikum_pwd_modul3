<html>
<head>
<title><?php echo 'belajar php'; ?></title><head>
<body>
<?php 
echo 'halo, dunia! <br />';
echo 'ini <i>script</i> php pertamaku';
?>
</body>
</html>